﻿namespace WindowsFormsApplication1
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calculator));
            this.button1_Number1 = new System.Windows.Forms.Button();
            this.button2_Number2 = new System.Windows.Forms.Button();
            this.button3_Number3 = new System.Windows.Forms.Button();
            this.button4_Number4 = new System.Windows.Forms.Button();
            this.button5_Number5 = new System.Windows.Forms.Button();
            this.button6_Number6 = new System.Windows.Forms.Button();
            this.button7_Number7 = new System.Windows.Forms.Button();
            this.button8_Number8 = new System.Windows.Forms.Button();
            this.button9_Number9 = new System.Windows.Forms.Button();
            this.button10_Clear = new System.Windows.Forms.Button();
            this.button11_Plus = new System.Windows.Forms.Button();
            this.button12_Minus = new System.Windows.Forms.Button();
            this.button13_Multiply = new System.Windows.Forms.Button();
            this.button14_Division = new System.Windows.Forms.Button();
            this.button15_Number0 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1_InterestCalculator = new System.Windows.Forms.Button();
            this.button2_ExchangeRateCalculator = new System.Windows.Forms.Button();
            this.button3_CompoundInterestCalculator = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1_Number1
            // 
            this.button1_Number1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button1_Number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1_Number1.Location = new System.Drawing.Point(12, 133);
            this.button1_Number1.Name = "button1_Number1";
            this.button1_Number1.Size = new System.Drawing.Size(74, 49);
            this.button1_Number1.TabIndex = 0;
            this.button1_Number1.Text = "1";
            this.button1_Number1.UseVisualStyleBackColor = true;
            this.button1_Number1.Click += new System.EventHandler(this.button1_Number1_Click);
            // 
            // button2_Number2
            // 
            this.button2_Number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2_Number2.Location = new System.Drawing.Point(110, 133);
            this.button2_Number2.Name = "button2_Number2";
            this.button2_Number2.Size = new System.Drawing.Size(74, 49);
            this.button2_Number2.TabIndex = 1;
            this.button2_Number2.Text = "2";
            this.button2_Number2.UseVisualStyleBackColor = true;
            this.button2_Number2.Click += new System.EventHandler(this.button2_Number2_Click);
            // 
            // button3_Number3
            // 
            this.button3_Number3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3_Number3.Location = new System.Drawing.Point(207, 133);
            this.button3_Number3.Name = "button3_Number3";
            this.button3_Number3.Size = new System.Drawing.Size(74, 49);
            this.button3_Number3.TabIndex = 2;
            this.button3_Number3.Text = "3";
            this.button3_Number3.UseVisualStyleBackColor = true;
            this.button3_Number3.Click += new System.EventHandler(this.button3_Number3_Click);
            // 
            // button4_Number4
            // 
            this.button4_Number4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4_Number4.Location = new System.Drawing.Point(12, 203);
            this.button4_Number4.Name = "button4_Number4";
            this.button4_Number4.Size = new System.Drawing.Size(74, 49);
            this.button4_Number4.TabIndex = 3;
            this.button4_Number4.Text = "4";
            this.button4_Number4.UseVisualStyleBackColor = true;
            this.button4_Number4.Click += new System.EventHandler(this.button4_Number4_Click);
            // 
            // button5_Number5
            // 
            this.button5_Number5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5_Number5.Location = new System.Drawing.Point(110, 203);
            this.button5_Number5.Name = "button5_Number5";
            this.button5_Number5.Size = new System.Drawing.Size(74, 49);
            this.button5_Number5.TabIndex = 4;
            this.button5_Number5.Text = "5";
            this.button5_Number5.UseVisualStyleBackColor = true;
            this.button5_Number5.Click += new System.EventHandler(this.button5_Number5_Click);
            // 
            // button6_Number6
            // 
            this.button6_Number6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6_Number6.Location = new System.Drawing.Point(207, 203);
            this.button6_Number6.Name = "button6_Number6";
            this.button6_Number6.Size = new System.Drawing.Size(74, 49);
            this.button6_Number6.TabIndex = 5;
            this.button6_Number6.Text = "6";
            this.button6_Number6.UseVisualStyleBackColor = true;
            this.button6_Number6.Click += new System.EventHandler(this.button6_Number6_Click);
            // 
            // button7_Number7
            // 
            this.button7_Number7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7_Number7.Location = new System.Drawing.Point(12, 276);
            this.button7_Number7.Name = "button7_Number7";
            this.button7_Number7.Size = new System.Drawing.Size(74, 49);
            this.button7_Number7.TabIndex = 6;
            this.button7_Number7.Text = "7";
            this.button7_Number7.UseVisualStyleBackColor = true;
            this.button7_Number7.Click += new System.EventHandler(this.button7_Number7_Click);
            // 
            // button8_Number8
            // 
            this.button8_Number8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8_Number8.Location = new System.Drawing.Point(110, 276);
            this.button8_Number8.Name = "button8_Number8";
            this.button8_Number8.Size = new System.Drawing.Size(74, 49);
            this.button8_Number8.TabIndex = 7;
            this.button8_Number8.Text = "8";
            this.button8_Number8.UseVisualStyleBackColor = true;
            this.button8_Number8.Click += new System.EventHandler(this.button8_Number8_Click);
            // 
            // button9_Number9
            // 
            this.button9_Number9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9_Number9.Location = new System.Drawing.Point(207, 276);
            this.button9_Number9.Name = "button9_Number9";
            this.button9_Number9.Size = new System.Drawing.Size(74, 49);
            this.button9_Number9.TabIndex = 8;
            this.button9_Number9.Text = "9";
            this.button9_Number9.UseVisualStyleBackColor = true;
            this.button9_Number9.Click += new System.EventHandler(this.button9_Number9_Click);
            // 
            // button10_Clear
            // 
            this.button10_Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10_Clear.Location = new System.Drawing.Point(12, 406);
            this.button10_Clear.Name = "button10_Clear";
            this.button10_Clear.Size = new System.Drawing.Size(269, 49);
            this.button10_Clear.TabIndex = 9;
            this.button10_Clear.Text = "Clear";
            this.button10_Clear.UseVisualStyleBackColor = true;
            this.button10_Clear.Click += new System.EventHandler(this.button10_Clear_Click);
            // 
            // button11_Plus
            // 
            this.button11_Plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11_Plus.Location = new System.Drawing.Point(331, 133);
            this.button11_Plus.Name = "button11_Plus";
            this.button11_Plus.Size = new System.Drawing.Size(74, 49);
            this.button11_Plus.TabIndex = 10;
            this.button11_Plus.Text = "+";
            this.button11_Plus.UseVisualStyleBackColor = true;
            this.button11_Plus.Click += new System.EventHandler(this.button11_Plus_Click);
            // 
            // button12_Minus
            // 
            this.button12_Minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12_Minus.Location = new System.Drawing.Point(331, 203);
            this.button12_Minus.Name = "button12_Minus";
            this.button12_Minus.Size = new System.Drawing.Size(74, 49);
            this.button12_Minus.TabIndex = 11;
            this.button12_Minus.Text = "-";
            this.button12_Minus.UseVisualStyleBackColor = true;
            this.button12_Minus.Click += new System.EventHandler(this.button12_Minus_Click);
            // 
            // button13_Multiply
            // 
            this.button13_Multiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13_Multiply.Location = new System.Drawing.Point(331, 276);
            this.button13_Multiply.Name = "button13_Multiply";
            this.button13_Multiply.Size = new System.Drawing.Size(74, 49);
            this.button13_Multiply.TabIndex = 12;
            this.button13_Multiply.Text = "*";
            this.button13_Multiply.UseVisualStyleBackColor = true;
            this.button13_Multiply.Click += new System.EventHandler(this.button13_Multiply_Click);
            // 
            // button14_Division
            // 
            this.button14_Division.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14_Division.Location = new System.Drawing.Point(331, 343);
            this.button14_Division.Name = "button14_Division";
            this.button14_Division.Size = new System.Drawing.Size(74, 49);
            this.button14_Division.TabIndex = 13;
            this.button14_Division.Text = "/";
            this.button14_Division.UseVisualStyleBackColor = true;
            this.button14_Division.Click += new System.EventHandler(this.button14_Division_Click);
            // 
            // button15_Number0
            // 
            this.button15_Number0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15_Number0.Location = new System.Drawing.Point(12, 343);
            this.button15_Number0.Name = "button15_Number0";
            this.button15_Number0.Size = new System.Drawing.Size(269, 49);
            this.button15_Number0.TabIndex = 14;
            this.button15_Number0.Text = "0";
            this.button15_Number0.UseVisualStyleBackColor = true;
            this.button15_Number0.Click += new System.EventHandler(this.button15_Number0_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 71);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(393, 20);
            this.textBox1.TabIndex = 15;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(322, 37);
            this.label1.TabIndex = 16;
            this.label1.Text = "Dimension Calculator";
            // 
            // button1_InterestCalculator
            // 
            this.button1_InterestCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1_InterestCalculator.Location = new System.Drawing.Point(531, 61);
            this.button1_InterestCalculator.Name = "button1_InterestCalculator";
            this.button1_InterestCalculator.Size = new System.Drawing.Size(230, 58);
            this.button1_InterestCalculator.TabIndex = 17;
            this.button1_InterestCalculator.Text = "Simple and Compound Interest Calculator";
            this.button1_InterestCalculator.UseVisualStyleBackColor = true;
            this.button1_InterestCalculator.Click += new System.EventHandler(this.button1_InterestCalculator_Click);
            // 
            // button2_ExchangeRateCalculator
            // 
            this.button2_ExchangeRateCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2_ExchangeRateCalculator.Location = new System.Drawing.Point(531, 177);
            this.button2_ExchangeRateCalculator.Name = "button2_ExchangeRateCalculator";
            this.button2_ExchangeRateCalculator.Size = new System.Drawing.Size(230, 58);
            this.button2_ExchangeRateCalculator.TabIndex = 18;
            this.button2_ExchangeRateCalculator.Text = "Exchange Rate Calculator";
            this.button2_ExchangeRateCalculator.UseVisualStyleBackColor = true;
            this.button2_ExchangeRateCalculator.Click += new System.EventHandler(this.button2_ExchangeRateCalculator_Click);
            // 
            // button3_CompoundInterestCalculator
            // 
            this.button3_CompoundInterestCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3_CompoundInterestCalculator.Location = new System.Drawing.Point(531, 257);
            this.button3_CompoundInterestCalculator.Name = "button3_CompoundInterestCalculator";
            this.button3_CompoundInterestCalculator.Size = new System.Drawing.Size(230, 58);
            this.button3_CompoundInterestCalculator.TabIndex = 19;
            this.button3_CompoundInterestCalculator.Text = "Arrays";
            this.button3_CompoundInterestCalculator.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(434, 133);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 322);
            this.button1.TabIndex = 20;
            this.button1.Text = "=";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(331, 404);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(70, 48);
            this.button2.TabIndex = 21;
            this.button2.Text = ",";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(531, 361);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(230, 49);
            this.button3.TabIndex = 22;
            this.button3.Text = "About the Calcluator";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(818, 467);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3_CompoundInterestCalculator);
            this.Controls.Add(this.button2_ExchangeRateCalculator);
            this.Controls.Add(this.button1_InterestCalculator);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button15_Number0);
            this.Controls.Add(this.button14_Division);
            this.Controls.Add(this.button13_Multiply);
            this.Controls.Add(this.button12_Minus);
            this.Controls.Add(this.button11_Plus);
            this.Controls.Add(this.button10_Clear);
            this.Controls.Add(this.button9_Number9);
            this.Controls.Add(this.button8_Number8);
            this.Controls.Add(this.button7_Number7);
            this.Controls.Add(this.button6_Number6);
            this.Controls.Add(this.button5_Number5);
            this.Controls.Add(this.button4_Number4);
            this.Controls.Add(this.button3_Number3);
            this.Controls.Add(this.button2_Number2);
            this.Controls.Add(this.button1_Number1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1_Number1;
        private System.Windows.Forms.Button button2_Number2;
        private System.Windows.Forms.Button button3_Number3;
        private System.Windows.Forms.Button button4_Number4;
        private System.Windows.Forms.Button button5_Number5;
        private System.Windows.Forms.Button button6_Number6;
        private System.Windows.Forms.Button button7_Number7;
        private System.Windows.Forms.Button button8_Number8;
        private System.Windows.Forms.Button button9_Number9;
        private System.Windows.Forms.Button button10_Clear;
        private System.Windows.Forms.Button button11_Plus;
        private System.Windows.Forms.Button button12_Minus;
        private System.Windows.Forms.Button button13_Multiply;
        private System.Windows.Forms.Button button14_Division;
        private System.Windows.Forms.Button button15_Number0;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1_InterestCalculator;
        private System.Windows.Forms.Button button2_ExchangeRateCalculator;
        private System.Windows.Forms.Button button3_CompoundInterestCalculator;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}